このプログラムは総理大臣ページを生成します。
実行の方法は以下の通りです。

このREADME.txtが存在するディレクトリで次のコマンドを入れてください。

$ make test

または

$ python PrimeMinisters.py ; open ~/Desktop/SouriDaijin/index.html

すると、デスクトップにSouriDaijinというディレクトリができますから、
その中のindex.htmlをダブルクリックすることで、
いつでも総理大臣ページを見ることができます。

詳しくは次のページをご覧ください。
http://www.cc.kyoto-su.ac.jp/~atsushi/Programs/CSV2HTML/index-j.html

--- 青木淳